/*--------------------------------------------------------------------------------
Procedure: stp_IncluirUsuario
Objetivo: Inclui usu�rio na tabela de usu�rios.
Data de Cria��o: 27/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_IncluirUsuario 
@Nome AS VARCHAR(100),
@Sexo AS CHAR(1),
@Usuario VARCHAR(20),
@Senha VARCHAR(20),
@DataNascimento AS DATE

AS
BEGIN
	SET NOCOUNT ON

	DECLARE @ID AS INT

	SELECT @ID = (ISNULL(MAX(ID), 0) + 1) FROM Usuarios

	INSERT INTO Usuarios 
	VALUES (@ID, @Nome, @Sexo, @Usuario, PWDENCRYPT(@Senha), @DataNascimento)
END
-- Fim da Procedure