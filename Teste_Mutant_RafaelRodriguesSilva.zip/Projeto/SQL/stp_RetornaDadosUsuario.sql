/*--------------------------------------------------------------------------------
Procedure: stp_RetornaDadosUsuario
Objetivo: Retorna os dados de um usu�rio espec�fico.
Data de Cria��o: 27/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_RetornaDadosUsuario 
@ID AS INT

AS
BEGIN
	SET NOCOUNT ON

	SELECT * 
	  FROM Usuarios
	 WHERE ID = @ID
END
-- Fim da Procedure