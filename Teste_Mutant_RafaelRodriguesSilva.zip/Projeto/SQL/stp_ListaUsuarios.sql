/*--------------------------------------------------------------------------------
Procedure: stp_ValidaLogin
Objetivo: Valida os dados de Login.
Data de Cria��o: 26/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_ValidaLogin 
@Usuario AS VARCHAR(20),
@Senha AS VARCHAR(20)

AS
BEGIN
	SET NOCOUNT ON

	DECLARE @ID AS INT

	SELECT @ID = ID 
	  FROM Usuarios
	 WHERE vLogin = @Usuario
       AND PWDCOMPARE(@Senha, vSenha) = 1
END
-- Fim da Procedure