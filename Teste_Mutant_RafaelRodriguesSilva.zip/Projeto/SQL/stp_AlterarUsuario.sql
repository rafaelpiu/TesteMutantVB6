/*--------------------------------------------------------------------------------
Procedure: stp_AlterarUsuario
Objetivo: Altera informa��es do usu�rio.
Data de Cria��o: 27/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_AlterarUsuario 
@ID AS INT,
@Nome AS VARCHAR(100),
@Sexo AS CHAR(1),
@Usuario VARCHAR(20),
@Senha VARCHAR(20),
@DataNascimento AS DATE

AS
BEGIN
	SET NOCOUNT ON

	SELECT * FROM Usuarios

	UPDATE Usuarios 
	   SET vNome = @Nome, 
		   cSexo = @Sexo, 
		   vLogin = @Usuario, 
		   dDt_Nascimento = @DataNascimento
	 WHERE ID = @ID

	 IF @Senha <> '' 
		UPDATE Usuarios 
		   SET vSenha = PWDENCRYPT(@Senha)
		 WHERE ID = @ID
END
-- Fim da Procedure