/*--------------------------------------------------------------------------------
Procedure: stp_ExcluirUsuario
Objetivo: Exclui usu�rio indicado.
Data de Cria��o: 26/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_ExcluirUsuario 
@ID AS INT

AS
BEGIN
	SET NOCOUNT ON

	DELETE FROM Usuarios WHERE ID = @ID
END
-- Fim da Procedure