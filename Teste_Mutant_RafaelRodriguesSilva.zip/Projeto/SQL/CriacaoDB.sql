---------------
--- Cria DB ---
---------------

IF NOT EXISTS (SELECT * FROM sys.databases WHERE NAME = 'Mutant_TesteRafael')
	CREATE DATABASE Mutant_TesteRafael
GO

USE Mutant_TesteRafael
GO

---------------------
--- Exclui Tabela ---
---------------------

IF OBJECT_ID('dbo.Usuarios') IS NOT NULL
	DROP TABLE Usuarios

GO

-------------------
--- Cria Tabela ---
-------------------

-- Cria Tabela Ingredientes
CREATE TABLE Usuarios
(
	ID INT NOT NULL PRIMARY KEY,
	vNome VARCHAR(100) NOT NULL,
	cSexo CHAR(1),
	vLogin VARCHAR(20) NOT NULL,
	vSenha VARBINARY(MAX) NOT NULL,
	dDt_Nascimento DATE NOT NULL
)

GO

-----------------------
--- Alimenta Tabela ---
-----------------------

-- Tabela Ingredientes
INSERT INTO Usuarios VALUES 
(1, 'Teste', 'M', 'teste', PWDENCRYPT('teste'), '2000-01-01')

GO